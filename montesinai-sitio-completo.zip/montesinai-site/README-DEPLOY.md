# 🏥 Monte Sinaí — Sistema Web Completo
## Guía de Deploy y Configuración de Dominio

---

## 📁 ESTRUCTURA DEL PROYECTO

```
montesinai-site/
├── index.html              ← Página principal (conecta todo)
├── vercel.json             ← Config deploy automático
├── pages/
│   ├── citas.html          ← Centro de citas y especialistas
│   ├── guia.html           ← Guía de acompañamiento + carrusel
│   └── glosario.html       ← Glosario médico interactivo
└── backend/
    ├── server.js            ← API Node.js
    ├── package.json
    ├── supabase-schema.sql  ← Base de datos
    └── n8n-hemodialisis-flow.json ← Automatización
```

---

## 🚀 OPCIÓN A — DEPLOY EN VERCEL (RECOMENDADO · GRATIS)

### Por qué Vercel:
- ✅ SSL/HTTPS automático
- ✅ CDN global (carga rápido en México y el mundo)
- ✅ Dominio .vercel.app gratis
- ✅ Dominio personalizado sin costo extra
- ✅ Deploy en 2 minutos
- ✅ Actualizaciones automáticas desde GitHub

### Paso 1 — Crear cuenta
```
1. Ve a https://vercel.com
2. Regístrate con tu correo o Google
3. Plan gratuito es suficiente para empezar
```

### Paso 2 — Subir el proyecto (sin GitHub)
```
1. Instala Vercel CLI en tu computadora:
   npm install -g vercel

2. Entra a la carpeta del proyecto:
   cd montesinai-site

3. Ejecuta:
   vercel deploy

4. Sigue las instrucciones:
   - Project name: monte-sinai
   - Framework: Other
   - Build command: (dejar vacío)
   - Output directory: . (punto)

5. Vercel te dará una URL como:
   https://monte-sinai-abc123.vercel.app
```

### Paso 3 — Conectar dominio personalizado
```
Si ya tienes dominio (Ej: montesinai.mx):

1. Ve a Vercel Dashboard → Tu proyecto → Settings → Domains
2. Escribe tu dominio: montesinai.mx
3. Vercel te dará 2 registros DNS para configurar

En tu proveedor de dominio (GoDaddy/NameCheap/Namecheap):
4. Agrega registro CNAME:
   Nombre: www
   Valor:   cname.vercel-dns.com

5. Agrega registro A:
   Nombre: @ (o vacío)
   Valor:   76.76.21.21

6. Espera 5-30 minutos
7. ¡Listo! Tu sitio estará en montesinai.mx con HTTPS
```

---

## 🌐 OPCIÓN B — HOSTINGER / CPANEL (Más fácil si ya tienes hosting)

```
1. Entra a cPanel de tu hosting
2. Ve a "Administrador de archivos"
3. Abre la carpeta public_html
4. Sube todos los archivos:
   - index.html
   - vercel.json (ignorar en cPanel)
   - Carpeta pages/ completa

5. Tu sitio ya estará activo en tu dominio
6. Para SSL: en cPanel → SSL/TLS → Let's Encrypt (gratis)
```

---

## ⚙️ CONFIGURAR EL BACKEND (API de leads)

### Deploy en Railway (recomendado · $5/mes)
```
1. Ve a https://railway.app
2. New Project → Deploy from GitHub
   (O arrastra la carpeta backend/)

3. Configura las variables de entorno:
   PORT=3001
   NODE_ENV=production
   SUPABASE_URL=https://TUPROYECTO.supabase.co
   SUPABASE_SERVICE_KEY=eyJhbGci...
   N8N_WEBHOOK_URL=https://tu-n8n.com/webhook/...
   FRONTEND_URL=https://montesinai.mx
   PHONE_EMERGENCY=5219000000000

4. Railway te dará una URL como:
   https://monte-sinai-api.up.railway.app

5. IMPORTANTE: En las páginas HTML, actualizar la URL del API:
   Buscar: fetch('/api/leads'
   Cambiar a: fetch('https://monte-sinai-api.up.railway.app/api/leads'
```

### Alternativa gratis: Render.com
```
1. https://render.com → New → Web Service
2. Conecta GitHub o sube los archivos backend/
3. Build command: npm install
4. Start command: node server.js
5. Plan FREE (tiene cold start de ~30s, aceptable)
```

---

## 🗄️ CONFIGURAR SUPABASE (Base de datos)

```
1. Ve a https://supabase.com
2. New Project → Nombre: monte-sinai
3. Ve a SQL Editor → New Query
4. Pega el contenido de: backend/supabase-schema.sql
5. Ejecuta (botón Run)
6. Ve a Settings → API:
   - Project URL → copia a SUPABASE_URL
   - service_role key → copia a SUPABASE_SERVICE_KEY
```

---

## 🤖 CONFIGURAR N8N (Automatización WhatsApp)

```
1. Ve a https://n8n.io → Start for free
2. New Workflow → Import from File
3. Sube: backend/n8n-hemodialisis-flow.json
4. Configura credenciales:
   - WhatsApp Business API (Meta Developers)
   - Telegram (BotFather)
   - SMTP (para emails)
5. Activa el workflow
6. Copia la URL del nodo Webhook → pega en RAILWAY como N8N_WEBHOOK_URL
```

---

## 📱 DOMINIO RECOMENDADO PARA MONTE SINAÍ

```
Opciones disponibles (verificar disponibilidad):
✅ montesinai.mx           ← Ideal para México
✅ hospitalmontesinai.mx
✅ clinicamontesinai.com
✅ montesinai-renal.mx

Dónde comprar dominio .mx barato:
- namecheap.com (~$12 USD/año)
- godaddy.com (~$15 USD/año)
- hostinger.mx (~$8 USD/año)
```

---

## ✅ CHECKLIST DE LANZAMIENTO

### Antes de publicar:
- [ ] Actualizar teléfono real: buscar "5219000000000" y reemplazar en todos los HTML
- [ ] Actualizar número de WhatsApp en todos los enlaces wa.me/
- [ ] Actualizar correo de contacto en footer
- [ ] Verificar dirección/ubicación en footer
- [ ] Cambiar horarios reales de atención

### Deploy:
- [ ] Frontend subido a Vercel o Hostinger
- [ ] Dominio personalizado configurado
- [ ] SSL/HTTPS activo (candado verde en el navegador)
- [ ] Backend en Railway con variables de entorno

### Integración:
- [ ] Supabase con tabla leads creada
- [ ] n8n workflow activo
- [ ] Probar formulario completo (enviar lead de prueba)
- [ ] Verificar que llegan notificaciones WhatsApp/Telegram

### SEO básico:
- [ ] Actualizar meta description con datos reales
- [ ] Google Search Console: agregar propiedad del dominio
- [ ] Google Analytics o PostHog instalado

---

## 🔧 ACTUALIZAR DATOS REALES

Buscar y reemplazar en todos los archivos HTML:

| Buscar                    | Reemplazar con              |
|---------------------------|----------------------------|
| 5219000000000             | Número real de WhatsApp    |
| +5219000000000            | Teléfono real con lada     |
| contacto@montesinai.com   | Correo real                |
| Lun–Vie 7am–9pm           | Horario real               |
| Ver ubicación             | Dirección real             |

---

## 💰 COSTO TOTAL ESTIMADO (mensual)

| Servicio          | Plan        | Costo/mes  |
|-------------------|-------------|-----------|
| Vercel (frontend) | Hobby       | GRATIS    |
| Railway (backend) | Starter     | ~$5 USD   |
| Supabase (DB)     | Free        | GRATIS    |
| n8n (automación)  | Starter     | ~$20 USD  |
| Dominio .mx       | Anual       | ~$1 USD   |
| **TOTAL**         |             | **~$26/mes** |

---

## 📞 SOPORTE

Si necesitas ayuda con el deploy, estos recursos son útiles:
- Vercel Docs: https://vercel.com/docs
- Supabase Docs: https://supabase.com/docs
- Railway Docs: https://docs.railway.app
- n8n Docs: https://docs.n8n.io
