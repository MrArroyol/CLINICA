/**
 * ══════════════════════════════════════════════════════════════
 * BACKEND: SISTEMA DE LEADS — CLÍNICA DE HEMODIÁLISIS
 * Stack: Node.js + Express + Supabase + n8n Webhook
 * ══════════════════════════════════════════════════════════════
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { createClient } = require('@supabase/supabase-js');
const { body, validationResult } = require('express-validator');
require('dotenv').config();

const app = express();

// ──────────────────────────────────────────
// CONFIGURACIÓN
// ──────────────────────────────────────────
const PORT = process.env.PORT || 3001;
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY;
const N8N_WEBHOOK_URL = process.env.N8N_WEBHOOK_URL;

if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY) {
  console.error('❌ SUPABASE_URL y SUPABASE_SERVICE_KEY son requeridos en .env');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

// ──────────────────────────────────────────
// MIDDLEWARES
// ──────────────────────────────────────────
app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));

// Rate limiting: máximo 5 solicitudes por IP en 10 minutos (anti-spam)
const leadLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 5,
  message: {
    success: false,
    error: 'Demasiadas solicitudes. Por favor espera unos minutos.',
    code: 'RATE_LIMIT_EXCEEDED'
  },
  standardHeaders: true,
  legacyHeaders: false
});

// ──────────────────────────────────────────
// LÓGICA DE CLASIFICACIÓN DE PRIORIDAD
// ──────────────────────────────────────────

/**
 * Clasifica el lead en ALTA, MEDIA o BAJA prioridad
 * basándose en urgencia, diagnóstico, edad y seguro.
 *
 * @param {Object} data - Datos del lead
 * @returns {{ prioridad: 'alta'|'media'|'baja', score: number, razones: string[] }}
 */
function clasificarLead(data) {
  let score = 0;
  const razones = [];

  // Factor 1: Urgencia declarada (peso: 40%)
  const urgenciaScores = { alta: 40, media: 20, baja: 5, sin_definir: 10 };
  score += urgenciaScores[data.urgencia] || 10;
  if (data.urgencia === 'alta') razones.push('Urgencia declarada crítica');

  // Factor 2: Diagnóstico (peso: 30%)
  const diagnosticosAlto = ['insuficiencia_renal_aguda', 'insuficiencia_renal_cronica'];
  const diagnosticosMedio = ['diabetes_nefropatia', 'hipertension_renal'];
  if (diagnosticosAlto.includes(data.diagnostico)) {
    score += 30;
    razones.push(`Diagnóstico de alto riesgo: ${data.diagnostico}`);
  } else if (diagnosticosMedio.includes(data.diagnostico)) {
    score += 15;
    razones.push(`Diagnóstico de riesgo medio: ${data.diagnostico}`);
  } else if (data.diagnostico === 'sin_diagnostico') {
    score += 20; // Sin diagnóstico = potencialmente urgente
    razones.push('Sin diagnóstico previo — puede ser urgente');
  } else {
    score += 10;
  }

  // Factor 3: Edad del paciente (peso: 15%)
  const edad = parseInt(data.edad) || 0;
  if (edad >= 60) {
    score += 15;
    razones.push(`Paciente mayor: ${edad} años`);
  } else if (edad >= 40) {
    score += 8;
  } else {
    score += 5;
  }

  // Factor 4: Sin seguro = posible barrera → mayor urgencia de contacto (peso: 15%)
  if (data.seguro === 'ninguno' || data.seguro === '') {
    score += 15;
    razones.push('Sin cobertura de seguro médico');
  } else if (data.seguro === 'no_sabe') {
    score += 10;
    razones.push('Cobertura de seguro desconocida');
  } else {
    score += 5;
  }

  // Clasificación final
  let prioridad;
  if (score >= 70) prioridad = 'alta';
  else if (score >= 40) prioridad = 'media';
  else prioridad = 'baja';

  return { prioridad, score, razones };
}

// ──────────────────────────────────────────
// VALIDACIONES DEL FORMULARIO
// ──────────────────────────────────────────
const leadValidations = [
  body('nombre')
    .trim()
    .isLength({ min: 2, max: 100 })
    .withMessage('El nombre debe tener entre 2 y 100 caracteres')
    .matches(/^[a-zA-ZáéíóúÁÉÍÓÚñÑüÜ\s'-]+$/)
    .withMessage('El nombre solo puede contener letras y espacios'),

  body('telefono')
    .trim()
    .replace(/[\s\-\(\)\.]/g, '') // sanitizar antes de validar
    .isLength({ min: 10, max: 15 })
    .withMessage('El teléfono debe tener entre 10 y 15 dígitos')
    .matches(/^[0-9+]+$/)
    .withMessage('El teléfono solo puede contener números'),

  body('edad')
    .isInt({ min: 1, max: 120 })
    .withMessage('La edad debe ser un número entre 1 y 120'),

  body('urgencia')
    .isIn(['alta', 'media', 'baja', 'sin_definir'])
    .withMessage('Nivel de urgencia inválido'),

  body('diagnostico')
    .optional()
    .isIn([
      'insuficiencia_renal_cronica', 'insuficiencia_renal_aguda',
      'diabetes_nefropatia', 'hipertension_renal',
      'sin_diagnostico', 'otro', ''
    ])
    .withMessage('Diagnóstico inválido'),

  body('seguro')
    .optional()
    .isIn(['imss', 'issste', 'seguro_privado', 'ninguno', 'no_sabe', ''])
    .withMessage('Tipo de seguro inválido'),

  body('ubicacion')
    .optional()
    .trim()
    .isLength({ max: 100 })
    .withMessage('Ubicación demasiado larga'),
];

// ──────────────────────────────────────────
// HELPERS
// ──────────────────────────────────────────
async function enviarWebhookN8N(payload) {
  if (!N8N_WEBHOOK_URL) {
    console.warn('⚠️  N8N_WEBHOOK_URL no configurado. Saltando webhook.');
    return;
  }
  try {
    const response = await fetch(N8N_WEBHOOK_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(8000) // 8s timeout
    });
    if (!response.ok) {
      console.error(`❌ n8n webhook respondió con status ${response.status}`);
    } else {
      console.log('✅ Webhook n8n enviado correctamente');
    }
  } catch (err) {
    // No fallar la respuesta al cliente si n8n falla
    console.error('❌ Error enviando webhook n8n:', err.message);
  }
}

function sanitizarTelefono(tel) {
  return tel.replace(/[\s\-\(\)\.\+]/g, '').replace(/^52/, '');
}

// ──────────────────────────────────────────
// RUTAS
// ──────────────────────────────────────────

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

/**
 * POST /api/leads
 * Recibe un lead, lo clasifica, lo guarda en Supabase y dispara n8n.
 */
app.post('/api/leads', leadLimiter, leadValidations, async (req, res) => {
  // 1. Validar inputs
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({
      success: false,
      error: 'Datos inválidos en el formulario',
      detalles: errors.array().map(e => ({ campo: e.path, mensaje: e.msg }))
    });
  }

  const {
    nombre, telefono, edad, diagnostico = '',
    urgencia = 'sin_definir', seguro = '', ubicacion = '',
    fuente = 'landing'
  } = req.body;

  try {
    // 2. Clasificar lead
    const clasificacion = clasificarLead({ urgencia, diagnostico, edad, seguro });

    // 3. Preparar registro para Supabase
    const leadData = {
      nombre: nombre.trim(),
      telefono: sanitizarTelefono(telefono.toString()),
      edad: parseInt(edad),
      diagnostico: diagnostico || null,
      urgencia,
      seguro: seguro || null,
      ubicacion: ubicacion.trim() || null,
      prioridad: clasificacion.prioridad,
      score: clasificacion.score,
      razones_clasificacion: clasificacion.razones,
      fuente,
      ip_origen: req.ip || null,
      fecha: new Date().toISOString(),
      estado: 'nuevo' // nuevo | contactado | en_tratamiento | descartado
    };

    // 4. Guardar en Supabase
    const { data: leadGuardado, error: supabaseError } = await supabase
      .from('leads')
      .insert([leadData])
      .select('id, nombre, prioridad, fecha')
      .single();

    if (supabaseError) {
      console.error('❌ Error Supabase:', supabaseError);
      throw new Error('Error al guardar el lead en la base de datos');
    }

    console.log(`✅ Lead guardado: ${leadGuardado.id} | ${nombre} | Prioridad: ${clasificacion.prioridad.toUpperCase()}`);

    // 5. Disparar webhook a n8n (asíncrono, no bloqueante)
    enviarWebhookN8N({
      lead_id: leadGuardado.id,
      nombre: leadData.nombre,
      telefono: leadData.telefono,
      edad: leadData.edad,
      diagnostico: leadData.diagnostico,
      urgencia: leadData.urgencia,
      seguro: leadData.seguro,
      ubicacion: leadData.ubicacion,
      prioridad: clasificacion.prioridad,
      score: clasificacion.score,
      razones: clasificacion.razones,
      fecha: leadData.fecha,
      fuente: leadData.fuente
    });

    // 6. Responder al frontend
    return res.status(201).json({
      success: true,
      message: 'Tu solicitud fue recibida. Te contactaremos pronto.',
      lead_id: leadGuardado.id,
      prioridad: clasificacion.prioridad,
      tiempo_respuesta: clasificacion.prioridad === 'alta'
        ? 'En los próximos 15 minutos'
        : clasificacion.prioridad === 'media'
          ? 'En las próximas 2 horas'
          : 'En las próximas 24 horas'
    });

  } catch (err) {
    console.error('❌ Error en /api/leads:', err);
    return res.status(500).json({
      success: false,
      error: 'Hubo un problema al procesar tu solicitud. Por favor llámanos directamente.',
      contacto_emergencia: process.env.PHONE_EMERGENCY || '55 0000-0000'
    });
  }
});

// Catch-all 404
app.use((req, res) => {
  res.status(404).json({ success: false, error: 'Ruta no encontrada' });
});

// Error handler global
app.use((err, req, res, next) => {
  console.error('❌ Error no manejado:', err);
  res.status(500).json({ success: false, error: 'Error interno del servidor' });
});

// ──────────────────────────────────────────
// INICIAR SERVIDOR
// ──────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🏥 Servidor Nefrología+ iniciado`);
  console.log(`📡 Puerto: ${PORT}`);
  console.log(`🗄️  Supabase: ${SUPABASE_URL ? '✅ Conectado' : '❌ No configurado'}`);
  console.log(`🔗 n8n webhook: ${N8N_WEBHOOK_URL ? '✅ Configurado' : '⚠️  No configurado'}`);
  console.log(`\n`);
});

module.exports = app;
