-- ══════════════════════════════════════════════════════════════
-- SUPABASE SQL — SISTEMA DE LEADS HEMODIÁLISIS
-- Ejecutar en: Supabase > SQL Editor > New query
-- ══════════════════════════════════════════════════════════════

-- Extensión para UUIDs (ya incluida en Supabase, pero por si acaso)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ──────────────────────────────────────────
-- TABLA PRINCIPAL: leads
-- ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS leads (
  -- Identificador único
  id            UUID DEFAULT uuid_generate_v4() PRIMARY KEY,

  -- Datos del paciente / familiar
  nombre        TEXT NOT NULL CHECK (char_length(nombre) BETWEEN 2 AND 100),
  telefono      TEXT NOT NULL CHECK (telefono ~ '^[0-9]{10,15}$'),
  edad          INTEGER NOT NULL CHECK (edad BETWEEN 1 AND 120),

  -- Información médica
  diagnostico   TEXT CHECK (diagnostico IN (
                  'insuficiencia_renal_cronica',
                  'insuficiencia_renal_aguda',
                  'diabetes_nefropatia',
                  'hipertension_renal',
                  'sin_diagnostico',
                  'otro'
                )),

  -- Nivel de urgencia declarado por el usuario
  urgencia      TEXT NOT NULL DEFAULT 'sin_definir'
                  CHECK (urgencia IN ('alta', 'media', 'baja', 'sin_definir')),

  -- Seguro médico
  seguro        TEXT CHECK (seguro IN (
                  'imss', 'issste', 'seguro_privado', 'ninguno', 'no_sabe'
                )),

  -- Geografía
  ubicacion     TEXT,

  -- Clasificación automática por el backend
  prioridad     TEXT NOT NULL DEFAULT 'media'
                  CHECK (prioridad IN ('alta', 'media', 'baja')),
  score         INTEGER DEFAULT 0,  -- Puntuación 0-100
  razones_clasificacion TEXT[],     -- Array de razones del scoring

  -- Estado del lead en el pipeline CRM
  estado        TEXT NOT NULL DEFAULT 'nuevo'
                  CHECK (estado IN (
                    'nuevo',           -- Recién llegado, no contactado
                    'contactado',      -- Se hizo contacto inicial
                    'cita_agendada',   -- Tiene cita
                    'en_tratamiento',  -- Ya es paciente activo
                    'descartado'       -- No procede
                  )),

  -- Metadatos
  fuente        TEXT DEFAULT 'landing',
  ip_origen     INET,
  notas         TEXT,  -- Notas del agente que contacta

  -- Timestamps
  fecha         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ──────────────────────────────────────────
-- ÍNDICES para consultas frecuentes
-- ──────────────────────────────────────────
CREATE INDEX idx_leads_prioridad ON leads(prioridad);
CREATE INDEX idx_leads_estado ON leads(estado);
CREATE INDEX idx_leads_fecha ON leads(fecha DESC);
CREATE INDEX idx_leads_telefono ON leads(telefono);
CREATE INDEX idx_leads_prioridad_estado ON leads(prioridad, estado);

-- ──────────────────────────────────────────
-- TRIGGER: actualizar updated_at automáticamente
-- ──────────────────────────────────────────
CREATE OR REPLACE FUNCTION trigger_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_updated_at
  BEFORE UPDATE ON leads
  FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

-- ──────────────────────────────────────────
-- ROW LEVEL SECURITY (RLS)
-- ──────────────────────────────────────────
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;

-- Solo el service_role (backend) puede INSERT
CREATE POLICY "Backend puede insertar leads"
  ON leads FOR INSERT
  TO service_role
  WITH CHECK (true);

-- Solo el service_role puede SELECT y UPDATE
CREATE POLICY "Backend puede leer leads"
  ON leads FOR SELECT
  TO service_role
  USING (true);

CREATE POLICY "Backend puede actualizar leads"
  ON leads FOR UPDATE
  TO service_role
  USING (true);

-- ──────────────────────────────────────────
-- VISTA: Dashboard resumen para el equipo médico
-- ──────────────────────────────────────────
CREATE OR REPLACE VIEW vista_leads_dashboard AS
SELECT
  id,
  nombre,
  telefono,
  edad,
  diagnostico,
  urgencia,
  seguro,
  ubicacion,
  prioridad,
  score,
  estado,
  fecha,
  -- Tiempo desde que llegó el lead
  EXTRACT(EPOCH FROM (NOW() - fecha)) / 3600 AS horas_desde_registro
FROM leads
WHERE estado NOT IN ('descartado')
ORDER BY
  CASE prioridad WHEN 'alta' THEN 1 WHEN 'media' THEN 2 ELSE 3 END,
  fecha DESC;

-- ──────────────────────────────────────────
-- VISTA: Métricas de conversión (para CRO)
-- ──────────────────────────────────────────
CREATE OR REPLACE VIEW vista_metricas_conversion AS
SELECT
  DATE_TRUNC('day', fecha) AS dia,
  COUNT(*) AS total_leads,
  COUNT(*) FILTER (WHERE prioridad = 'alta') AS leads_alta,
  COUNT(*) FILTER (WHERE prioridad = 'media') AS leads_media,
  COUNT(*) FILTER (WHERE prioridad = 'baja') AS leads_baja,
  COUNT(*) FILTER (WHERE estado = 'cita_agendada') AS citas_agendadas,
  COUNT(*) FILTER (WHERE estado = 'en_tratamiento') AS convertidos,
  ROUND(
    100.0 * COUNT(*) FILTER (WHERE estado IN ('cita_agendada', 'en_tratamiento'))
    / NULLIF(COUNT(*), 0), 2
  ) AS tasa_conversion_pct
FROM leads
GROUP BY DATE_TRUNC('day', fecha)
ORDER BY dia DESC;

-- ──────────────────────────────────────────
-- DATO DE PRUEBA (opcional, comentar en prod)
-- ──────────────────────────────────────────
-- INSERT INTO leads (nombre, telefono, edad, diagnostico, urgencia, seguro, ubicacion, prioridad, score, estado)
-- VALUES ('María González (PRUEBA)', '5500000000', 65, 'insuficiencia_renal_cronica', 'alta', 'imss', 'CDMX', 'alta', 85, 'nuevo');

-- Verificar estructura:
-- SELECT column_name, data_type, is_nullable FROM information_schema.columns WHERE table_name = 'leads';
